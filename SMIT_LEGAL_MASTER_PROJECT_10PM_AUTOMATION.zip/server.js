const express = require('express');
const fs = require('fs');
const path = require('path');
const cron = require('node-cron');
const nodemailer = require('nodemailer');
const axios = require('axios');
const multer = require('multer');

const app = express();
app.use(express.json({limit:'2mb'}));
app.use(express.static(__dirname));

const PORT = process.env.PORT || 10000;
const DATA_DIR = path.join(__dirname, 'server-data');
const ORDERS_FILE = path.join(DATA_DIR, 'orders.json');
const REPORT_DIR = path.join(DATA_DIR, 'reports');
fs.mkdirSync(REPORT_DIR, {recursive:true});
if (!fs.existsSync(ORDERS_FILE)) fs.writeFileSync(ORDERS_FILE, '[]');

function readOrders(){ try{return JSON.parse(fs.readFileSync(ORDERS_FILE,'utf8')||'[]')}catch{return []} }
function writeOrders(orders){ fs.writeFileSync(ORDERS_FILE, JSON.stringify(Array.isArray(orders)?orders:[], null, 2)); }
function istDateString(date=new Date()) { return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit'}).format(date); }
function escCsv(v){ const s=String(v??''); return '"'+s.replaceAll('"','""')+'"'; }
function reportFor(date){
  const orders=readOrders().filter(o=>{
    const d=istDateString(new Date(o.paymentConfirmedAt || o.paidSubmittedAt || o.createdAt || 0));
    return d===date;
  });
  const paid=orders.filter(o=>o.paymentStatus==='Payment Confirmed');
  const gov=paid.reduce((n,o)=>n+Number(o.governmentFee||0),0);
  const service=paid.reduce((n,o)=>n+Number(o.serviceCharge||0),0);
  const total=paid.reduce((n,o)=>n+Number(o.total||0),0);
  const pending=orders.filter(o=>o.paymentStatus!=='Payment Confirmed').length;
  const rows=[['Order ID','Date','Customer','Service','Sub-service','Sub-option','Payment','Government Charges','Smit Service Charges','Total','Status','Transaction ID','Invoice']];
  for(const o of orders) rows.push([o.id,istDateString(new Date(o.createdAt||0)),o.name,o.service,o.subService,o.subOption,o.paymentStatus,Number(o.governmentFee||0),Number(o.serviceCharge||0),Number(o.total||0),o.status,o.transactionId,o.invoiceNo]);
  rows.push([]); rows.push(['SUMMARY','','','','','','Paid Orders',paid.length,'Government Charges',gov,'Smit Income',service,'Total Received',total,'Pending Orders',pending]);
  const csv=rows.map(r=>r.map(escCsv).join(',')).join('\n');
  return {date,orders,paid,gov,service,total,pending,csv};
}
function buildTransporter(){
  if(!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) return null;
  return nodemailer.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT||587),secure:String(process.env.SMTP_SECURE||'false')==='true',auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}});
}
async function sendEmail(report, filePath){
  const t=buildTransporter(); if(!t) throw new Error('SMTP settings are missing');
  const to=process.env.REPORT_EMAIL||'smitlegally@gmail.com';
  await t.sendMail({from:process.env.SMTP_FROM||process.env.SMTP_USER,to,subject:`SMIT Daily Work Report — ${report.date}`,text:`Daily report for ${report.date}\nPaid orders: ${report.paid.length}\nGovernment charges: ₹${report.gov}\nSmit service income: ₹${report.service}\nTotal received: ₹${report.total}\nPending orders: ${report.pending}`,attachments:[{filename:`SMIT-Daily-Report-${report.date}.csv`,path:filePath}]});
}
async function sendWhatsApp(report, filePath){
  const token=process.env.WHATSAPP_ACCESS_TOKEN, phoneId=process.env.WHATSAPP_PHONE_NUMBER_ID, to=(process.env.REPORT_WHATSAPP||'').replace(/\D/g,'');
  if(!token||!phoneId||!to) throw new Error('WhatsApp Cloud API settings are missing');
  const graph=`https://graph.facebook.com/${process.env.WHATSAPP_API_VERSION||'v23.0'}`;
  const media=await axios.post(`${graph}/${phoneId}/media`, require('fs').createReadStream(filePath), {headers:{Authorization:`Bearer ${token}`,'Content-Type':'text/csv'},params:{messaging_product:'whatsapp',type:'document'}});
  const mediaId=media.data.id;
  await axios.post(`${graph}/${phoneId}/messages`,{messaging_product:'whatsapp',to,type:'document',document:{id:mediaId,filename:path.basename(filePath),caption:`SMIT Daily Work Report — ${report.date}\nPaid: ${report.paid.length}\nGovt: ₹${report.gov}\nSmit Income: ₹${report.service}\nTotal: ₹${report.total}`}}, {headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'}});
}
async function generateAndDeliver(date=istDateString()){
  const report=reportFor(date); const filePath=path.join(REPORT_DIR,`SMIT-Daily-Report-${date}.csv`); fs.writeFileSync(filePath,report.csv);
  const result={date,file:filePath,email:null,whatsapp:null};
  try{await sendEmail(report,filePath);result.email='sent'}catch(e){result.email='failed: '+e.message;console.error('Email delivery:',e.message)}
  try{await sendWhatsApp(report,filePath);result.whatsapp='sent'}catch(e){result.whatsapp='failed: '+e.message;console.error('WhatsApp delivery:',e.message)}
  return result;
}

app.get('/api/health',(req,res)=>res.json({ok:true,time:new Date().toISOString(),timezone:'Asia/Kolkata'}));
app.get('/api/orders',(req,res)=>res.json({orders:readOrders()}));
app.post('/api/orders',(req,res)=>{if(!Array.isArray(req.body.orders))return res.status(400).json({error:'orders must be an array'});writeOrders(req.body.orders);res.json({ok:true,count:req.body.orders.length});});
app.get('/api/daily-report',(req,res)=>{const date=/^\d{4}-\d{2}-\d{2}$/.test(req.query.date||'')?req.query.date:istDateString();const r=reportFor(date);res.type('text/csv').send(r.csv);});
app.post('/api/daily-report/generate',(req,res)=>{generateAndDeliver(req.body?.date||istDateString()).then(r=>res.json({ok:true,...r})).catch(e=>res.status(500).json({ok:false,error:e.message}));});

// 10:00 PM India time, every day. Set DISABLE_DAILY_CRON=true to turn it off.
if(process.env.DISABLE_DAILY_CRON!=='true') cron.schedule('0 22 * * *',()=>generateAndDeliver(istDateString()).catch(console.error),{timezone:'Asia/Kolkata'});

app.listen(PORT,()=>console.log(`Smit Legal server running on port ${PORT}; daily report scheduler: ${process.env.DISABLE_DAILY_CRON==='true'?'OFF':'ON at 22:00 IST'}`));
