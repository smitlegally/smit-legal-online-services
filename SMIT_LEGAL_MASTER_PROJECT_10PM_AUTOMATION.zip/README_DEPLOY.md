# SMIT Legal Master Project

## Files
- `index.html` — website + admin panel + invoice + tracking + daily report UI
- `server.js` — Express server, order sync, report API, 10 PM IST scheduler, email/WhatsApp delivery
- `package.json` — Render start configuration
- `.env.example` — required environment variables

## Render
Use **Node** service with:
- Build command: `npm install`
- Start command: `npm start`

Add the environment variables from `.env.example` in Render. Do not put passwords/tokens into `index.html` or GitHub.

The server cron runs every day at **22:00 Asia/Kolkata** and generates the CSV report from confirmed/pending orders synced by the website.

### Email
Configure SMTP credentials. `REPORT_EMAIL` defaults to `smitlegally@gmail.com`.

### WhatsApp
Configure WhatsApp Cloud API token + phone number ID + destination number. For unattended business-initiated WhatsApp messages, Meta may require an approved WhatsApp template depending on the conversation window/policy. The server sends the generated CSV as a document when the API permits it.

## Important data model note
The existing site stores orders in browser localStorage. This master build also syncs the current order array to `/api/orders` whenever orders are saved, so the server has the data required for the 10 PM report. Existing orders on a browser are pushed once when the page loads.
