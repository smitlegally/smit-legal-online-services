# Smit Legal Final Implementation
Email: smitlegally@gmail.com
OTP: disabled
Default Government/Official Fee: ₹200
Default Smit Service Charge: ₹200
Default Total: ₹400
Languages: Marathi / English / Hindi
Workflow: Service → Sub-service → Documents → Guidance → WhatsApp → Order ID → Payment → Transaction ID → Tracking
Password change notification: WhatsApp deep-link (automatic provider delivery requires credentials)
