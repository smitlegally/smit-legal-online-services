# Smit Legal and Online Services
Render-ready Node/Express project.

Build command: `npm install`
Start command: `npm start`

No real API secrets are included. Add provider credentials as environment variables only if/when needed.
