SMIT FINAL MASTER - STABLE FLOW VERIFIED. Deploy index.html. Customer chat flow is one level at a time. Admin remains available only through the existing admin access mechanism.
