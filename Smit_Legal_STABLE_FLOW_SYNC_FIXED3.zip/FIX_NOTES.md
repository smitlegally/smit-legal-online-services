Fixed the invoice-renderer JavaScript syntax error. This error was preventing the main chatbox/services JavaScript from initializing. Admin script retained.
